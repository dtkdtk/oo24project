const VERSION = "0.1";
const BUILD = 1;
function EXECUTE(AllCode) {
    if (AllCode.length == 0)
        return;
    const S = new StateExemplar(AllCode);
    const WordGenerator = S.MakeWordsGenerator();
    LoadStdDefinitions(S);
    for (const Word of WordGenerator) {
        InterpretWord(Word, S);
    }
    return S;
}
function InterpretWord(Word, S) {
    if (Word == "[[") {
        S.DefinitionStack.push(new DefinitionExemplar());
        return;
    }
    if (Word == "]]") {
        const Definition = S.DefinitionStack.pop();
        S.Stack.push(Definition);
        return;
    }
    if (S.DefinitionStack.length > 0) {
        S.DefinitionStack[S.DefinitionStack.length - 1].push(Word);
        return;
    }
    if (Word == "DEFINE") {
        const VarName = S.Stack.pop();
        const VarValue = S.Stack.pop();
        S.Dict.set(VarName, VarValue);
        return;
    }
    const MaybeAsNumber = Number(Word);
    if (!isNaN(MaybeAsNumber)) {
        S.Stack.push(MaybeAsNumber);
        return;
    }
    if (Word.startsWith('`') && Word.endsWith('`')) {
        const WordUnquoted = Unquote(Word);
        S.Stack.push(WordUnquoted);
        return;
    }
    const MaybeDefinition = S.Dict.get(Word);
    if (MaybeDefinition === undefined)
        S.Stack.push(Word);
    else if (typeof MaybeDefinition == "function")
        MaybeDefinition(S);
    else if (MaybeDefinition instanceof DefinitionExemplar)
        for (const W of MaybeDefinition)
            InterpretWord(W, S);
    else
        S.Stack.push(MaybeDefinition);
}
class StateExemplar {
    constructor(AllCode) {
        this.Stack = [];
        this.Dict = new Map();
        this.DefinitionStack = [];
        this.ReaderPos = 0;
        this.WordIndex = 0;
        this.AllCode = AllCode;
    }
    *MakeWordsGenerator() {
        let Buf = "";
        let iComment = false;
        while (this.ReaderPos <= this.AllCode.length) {
            const Tk = this.AllCode[this.ReaderPos++];
            if (Tk == ")" && iComment) {
                iComment = false;
                continue;
            }
            if (iComment)
                continue;
            if (Tk == "(") {
                iComment = true;
                if (Buf.length > 0) {
                    this.WordIndex++;
                    yield Buf;
                    Buf = "";
                }
                continue;
            }
            if (Tk == " " || Tk == "\r" || Tk == "\n") {
                if (Buf.length > 0) {
                    this.WordIndex++;
                    yield Buf;
                    Buf = "";
                }
                continue;
            }
            Buf += Tk;
        }
        return Buf;
    }
}
class DefinitionExemplar extends Array {
    [Symbol.toStringTag]() {
        return "DefinitionExemplar";
    }
}
function Unquote(Target) {
    if (Target.length <= 2)
        return "";
    return Target.slice(1, Target.length - 1);
}
function LoadStdDefinitions(TheState) {
    TheState.Dict.set("null", (S) => {
        S.Stack.push(null);
    });
    TheState.Dict.set("true", (S) => {
        S.Stack.push(0x1);
    });
    TheState.Dict.set("false", (S) => {
        S.Stack.push(0x0);
    });
    TheState.Dict.set("Current_Interpreter_Version", (S) => {
        S.Stack.push(VERSION);
    });
    TheState.Dict.set("Current_Interpreter_Build", (S) => {
        S.Stack.push(BUILD);
    });
    TheState.Dict.set("Current_Interpreter_Name", (S) => {
        S.Stack.push("One3L-js");
    });
    TheState.Dict.set("dup", (S) => {
        const Value = S.Stack.at(-1);
        S.Stack.push(Value);
    });
    TheState.Dict.set("dupsub", (S) => {
        const Value = S.Stack.at(-2);
        S.Stack.push(Value);
    });
    TheState.Dict.set("dupat", (S) => {
        const Pos = S.Stack.pop();
        const Value = S.Stack.at(Pos);
        S.Stack.push(Value);
    });
    TheState.Dict.set("drop", (S) => {
        S.Stack.pop();
    });
    TheState.Dict.set("print", (S) => {
        const Value = S.Stack.pop();
        console.log(Value);
    });
    TheState.Dict.set("concat", (S) => {
        const B = String(S.Stack.pop());
        const A = S.Stack.pop();
        S.Stack.push(A + B);
    });
    TheState.Dict.set("exit_program", (S) => {
        const ExitCode = S.Stack.pop();
        if (ExitCode !== null
            && typeof global.process != "undefined"
            && typeof process.exit == "function") {
            process.exit(ExitCode);
        }
        else {
            S.ReaderPos = S.AllCode.length;
        }
    });
    TheState.Dict.set("[+]", (S) => {
        const B = S.Stack.pop();
        const A = S.Stack.pop();
        S.Stack.push(A + B);
    });
    TheState.Dict.set("[-]", (S) => {
        const B = S.Stack.pop();
        const A = S.Stack.pop();
        S.Stack.push(A - B);
    });
    TheState.Dict.set("[*]", (S) => {
        const B = S.Stack.pop();
        const A = S.Stack.pop();
        S.Stack.push(A * B);
    });
    TheState.Dict.set("[/]", (S) => {
        const B = S.Stack.pop();
        const A = S.Stack.pop();
        S.Stack.push(A / B);
    });
    TheState.Dict.set("[//]", (S) => {
        const B = S.Stack.pop();
        const A = S.Stack.pop();
        S.Stack.push(Math.floor(A / B));
    });
    TheState.Dict.set("[%]", (S) => {
        const B = S.Stack.pop();
        const A = S.Stack.pop();
        S.Stack.push(A % B);
    });
    TheState.Dict.set("increment", (S) => {
        const X = S.Stack.pop();
        S.Stack.push(X + 1);
    });
    TheState.Dict.set("decrement", (S) => {
        const X = S.Stack.pop();
        S.Stack.push(X - 1);
    });
    TheState.Dict.set("[==]", (S) => {
        const B = S.Stack.pop();
        const A = S.Stack.pop();
        S.Stack.push(A == B ? 0x1 : 0x0);
    });
    TheState.Dict.set("[!=]", (S) => {
        const B = S.Stack.pop();
        const A = S.Stack.pop();
        S.Stack.push(A != B ? 0x1 : 0x0);
    });
    TheState.Dict.set("[>]", (S) => {
        const B = S.Stack.pop();
        const A = S.Stack.pop();
        S.Stack.push(A > B ? 0x1 : 0x0);
    });
    TheState.Dict.set("[>=]", (S) => {
        const B = S.Stack.pop();
        const A = S.Stack.pop();
        S.Stack.push(A >= B ? 0x1 : 0x0);
    });
    TheState.Dict.set("[<]", (S) => {
        const B = S.Stack.pop();
        const A = S.Stack.pop();
        S.Stack.push(A < B ? 0x1 : 0x0);
    });
    TheState.Dict.set("[<=]", (S) => {
        const B = S.Stack.pop();
        const A = S.Stack.pop();
        S.Stack.push(A <= B ? 0x1 : 0x0);
    });
    TheState.Dict.set("not", (S) => {
        const X = S.Stack.pop();
        S.Stack.push(X == 0x1 ? 0x0 : 0x1);
    });
    TheState.Dict.set("bitnot", (S) => {
        const X = S.Stack.pop();
        S.Stack.push(~X);
    });
    TheState.Dict.set("and", (S) => {
        const B = S.Stack.pop();
        const A = S.Stack.pop();
        S.Stack.push(A & B);
    });
    TheState.Dict.set("or", (S) => {
        const B = S.Stack.pop();
        const A = S.Stack.pop();
        S.Stack.push(A | B);
    });
    TheState.Dict.set("bitxor", (S) => {
        const B = S.Stack.pop();
        const A = S.Stack.pop();
        S.Stack.push(A ^ B);
    });
    TheState.Dict.set("[<<]", (S) => {
        const Shift = S.Stack.pop();
        const X = S.Stack.pop();
        S.Stack.push(X << Shift);
    });
    TheState.Dict.set("[>>]", (S) => {
        const Shift = S.Stack.pop();
        const X = S.Stack.pop();
        S.Stack.push(X >> Shift);
    });
    TheState.Dict.set("[>>>]", (S) => {
        const Shift = S.Stack.pop();
        const X = S.Stack.pop();
        S.Stack.push(X >>> Shift);
    });
}
Object.defineProperty(global, "One3L_EXECUTE", { value: EXECUTE });
Object.defineProperty(global, "One3L_STATE", { value: StateExemplar });
